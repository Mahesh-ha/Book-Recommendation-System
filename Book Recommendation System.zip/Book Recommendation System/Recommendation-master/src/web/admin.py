from django.contrib import admin
from .models import Book,Myrating

admin.site.register(Book)
admin.site.register(Myrating)
# Register your models here.
